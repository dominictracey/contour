#undef HAVE_MOTIF
#undef HAVE_XP
#undef HAVE_XPM
