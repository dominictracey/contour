
#include "gpsd.h"
extern void register_canvas(Widget w, GC gc);
extern void draw_graphics();
