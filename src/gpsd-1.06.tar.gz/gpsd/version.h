#ifndef _VERSION_H
#define _VERSION_H

#define VERSION  "1.06"

#endif
